package org.example;
import org.example.logic.*;

import java.util.ArrayList;
import java.util.Random;

public class GameLogic {
    final int MOVE_LENGHT = 10; //pohyb enemies
    final int MAX_ENEMIES = 5; // pocet enemies
    Player player;

    ArrayList<Enemy> enemies;  // Seznam nepřátel
    ArrayList<Coin> coin;  // Seznam mincí
    int deathCount = 0;
    int score = 0;
    int topScore = 0;



    public GameLogic() {
        player = new Player(420, 820, "zlobak.png");  // Inicializace hráče na pozici (420, 820)

        enemies = new ArrayList<>();  // Vytvoření seznamu nepřátel
        coin = new ArrayList<>();  // Vytvoření seznamu mincí
        spawnCoins();  // Vygenerování počátečních mincí
        spawnEnemies();  // Vygenerování počátečních nepřátel
    }

    // Resetování hry
    public void resetGame() {
        player.coord.x = 920;  // Resetování pozice hráče
        player.coord.y = 800;

        for (Enemy enemy : enemies) {
            enemy.coord.x = enemy.startingX;  // Resetování počáteční pozice nepřítele
            enemy.coord.y = enemy.startingY;
        }

        coin.clear();  // Vymazání seznamu mincí
        spawnCoins();  // Vygenerování nových mincí na náhodných pozicích
        enemies.clear();  // Vymazání seznamu nepřátel
        spawnEnemies();  // Vygenerování nepřátel po resetu
        score = 0;  // Resetování skóre
    }

    // Aktualizace logiky hry
    public void update() {
        // Aktualizace pozic nepřátel
        for (Enemy enemy : enemies) {
            int dx = player.coord.x - enemy.coord.x;
            int dy = player.coord.y - enemy.coord.y;

            double length = Math.sqrt(dx * dx + dy * dy);

            if (length > 0) {
                int moveX = (int) (MOVE_LENGHT * (dx / length));
                int moveY = (int) (MOVE_LENGHT * (dy / length));
                enemy.coord.x += moveX;
                enemy.coord.y += moveY;
            }
        }

        checkCollisions();  // Kontrola kolizí po aktualizaci
    }

    // Kontrola kolizí s mincemi a nepřáteli
    public void checkCollisions() {
        // Kontrola kolizí s mincemi
        for (Coin c : coin) {
            if (player.getEntityRectangle().intersects(c.getCoinRectangle())) {
                coin.remove(c);  // Odstranění mince ze seznamu
                score++;  // Zvyšování skóre

                // Pokud skóre dosáhne určité hodnoty a není dosažen maximální počet nepřátel, spawn nového nepřítele
                if (score == 10 && enemies.size() < MAX_ENEMIES) {
                    spawnEnemies();
                }

                // Pokud je aktuální skóre vyšší než nejlepší skóre, aktualizuj nejlepší skóre
                if (score > topScore) {
                    topScore = score;
                }

                // Vytvoření nové mince na náhodné pozici po sebrání jedné
                Random rand = new Random();
                int randomX = rand.nextInt(980);
                int randomY = rand.nextInt(1800);
                Coin newCoin = new Coin(randomX, randomY, "coin.png");
                coin.add(newCoin);

                break;  // Ukončení po první kolizi, není potřeba kontrolovat další mince
            }
        }

        // Kontrola kolizí s nepřáteli
        for (Enemy enemy : enemies) {
            if (player.getEntityRectangle().intersects(enemy.getEntityRectangle())) {
                deathCount++;
                System.out.println("*** Game Over! ***");
                System.out.println("*** Final Score = " + score + " ***");
                System.out.println("*** Your best score = " + topScore + " ***");
                resetGame();  // Resetování hry po smrti hráče
            }
        }
    }

    public int getDeathCount() {
        return deathCount;
    }

    // Metoda pro vygenerování mincí na náhodných pozicích
    public void spawnCoins() {
        Random rand = new Random();
        for (int i = 0; i < 5; i++) {  // Generování 5 mincí
            int randomX = rand.nextInt(980);
            int randomY = rand.nextInt(1800);
            Coin newCoin = new Coin(randomX, randomY, "coin.png");
            coin.add(newCoin);
        }
    }

    // Metoda pro vygenerování nepřátel na náhodných pozicích, s omezením na maximální počet nepřátel
    public void spawnEnemies() {
        if (enemies.size() < MAX_ENEMIES) {  // Zajistí, že nebudeme mít více než MAX_ENEMIES nepřátel
            Random rand = new Random();
            int randomX = rand.nextInt(980);
            int randomY = rand.nextInt(1800);

            Enemy newEnemy = new Enemy(randomX, randomY, "monster.png");
            enemies.add(newEnemy);
        }
    }
}