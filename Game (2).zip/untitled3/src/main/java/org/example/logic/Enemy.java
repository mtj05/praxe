package org.example.logic;

import java.awt.*;

public class Enemy extends Entity {
    public int startingX, startingY;  // Uložení počátečních souřadnic

    public Enemy(int x, int y, String url) {
        super(x, y, url);
        this.startingX = x;  // počáteční pozice X
        this.startingY = y;  // počáteční pozice Y
    }
}

