package org.example.logic;

import javax.swing.*;
import java.awt.*;

public class Entity {
    public Coordinates coord;
    public Image image;
    private boolean jumping = false;

    public Entity(int x, int y, String url) {
        coord = new Coordinates(x, y);
        ImageIcon ii = new ImageIcon(getClass().getResource("/" + url));
        image = ii.getImage();
    }


    public void startJump() {
        jumping = true;  //  jumping state  true
    }


    public void endJump() {
        jumping = false;  // jumping state false
    }


    public Rectangle getEntityRectangle() {
        int hitbox = 55;


        if (jumping) {
            hitbox = 100;
        }

        return new Rectangle(
                coord.x + hitbox,
                coord.y + hitbox,
                image.getWidth(null) - (2 * hitbox),
                image.getHeight(null) - (2 * hitbox)
        );
    }


    public void move(int steps, Direction direction) {
        switch (direction) {
            case UP -> coord.y -= steps;
            case DOWN -> coord.y += steps;
            case LEFT -> coord.x -= steps;
            case RIGHT -> coord.x += steps;
        }
    }
}