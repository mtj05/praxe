package org.example.logic;

public enum Direction {
    LEFT, RIGHT, UP, DOWN
}
