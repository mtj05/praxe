package org.example.logic;

import javax.swing.*;
import java.awt.*;

public class Coin extends Entity{
    public Coin(int x, int y, String url) {
        super(x, y, url);
    }
    public Rectangle getCoinRectangle() {
        int hitbox = 10;
        return new Rectangle(
                coord.x + hitbox,
                coord.y + hitbox,
                image.getWidth(null) - (2 * hitbox),
                image.getHeight(null) - (2 * hitbox)
        );
    }
}