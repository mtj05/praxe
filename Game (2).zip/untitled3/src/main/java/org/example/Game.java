package org.example;

import java.awt.event.*;
import javax.swing.*;

public class Game {
    GameLogic logic;

    boolean w, s, a, d, space, esc;

    public Game() {
        logic = new GameLogic();
        GameGraphics graphics = new GameGraphics(logic);

        graphics.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_W -> w = true;
                    case KeyEvent.VK_S -> s = true;
                    case KeyEvent.VK_A -> a = true;
                    case KeyEvent.VK_D -> d = true;
                    case KeyEvent.VK_SPACE -> space = true;
                    case KeyEvent.VK_ESCAPE -> esc = true;
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_W -> w = false;
                    case KeyEvent.VK_S -> s = false;
                    case KeyEvent.VK_A -> a = false;
                    case KeyEvent.VK_D -> d = false;
                    case KeyEvent.VK_SPACE -> space = false;
                    case KeyEvent.VK_ESCAPE -> esc = false;
                }
            }
        });

        Timer timer = new Timer(16, e -> {
            int moveDistance = 12;
            int teleportDistance = 50;

            // Movement
            if (w) logic.player.coord.y -= moveDistance;
            if (s) logic.player.coord.y += moveDistance;
            if (a) logic.player.coord.x -= moveDistance;
            if (d) logic.player.coord.x += moveDistance;

            // teleporting when space is pressed
            if (w && space) logic.player.coord.y = logic.player.coord.y - teleportDistance;
            if (s && space) logic.player.coord.y = logic.player.coord.y + teleportDistance;
            if (a && space) logic.player.coord.x = logic.player.coord.x - teleportDistance;
            if (d && space) logic.player.coord.x = logic.player.coord.x + teleportDistance;

            // Handle jumping and hitbox shrinking
            if (space) {
                logic.player.startJump();  // Start jump, shrink hitbox
            } else {
                logic.player.endJump(); // End jump, reset hitbox
            }

            // Restart game (when escape is pressed)
            if (esc) {
                logic.resetGame();
            }

            graphics.render(logic);
        });
        timer.start();

        Timer timerEnemy = new Timer(16, e -> {
            logic.update();
            graphics.render(logic);
        });
        timerEnemy.start();
    }

    public static void main(String[] args) {
        new Game();
    }
}



